using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Actuators;
using Unity.MLAgents.Sensors;
using UnityEngine.UI;

public class CarControllerAgent : Agent
{
    [SerializeField] private TrackCheckpoints trackCheckpoints;
    [SerializeField] private Transform spawnPosition;
    [SerializeField] private int maxSteps = 3000;
    private float forwardSpeedReward = 0.0001f;
    private float perStepPenalty = -0.001f;
//
    [SerializeField] private float timer = 30f;
    [SerializeField] private Text value;
    [SerializeField] private Text checksGone;
    [SerializeField] private Text allChecks;
    [SerializeField] private Text rewardNum;
    [SerializeField] private Text speedText;
    private bool start = false;
    private int checksOver = 0;
//
    private int stepCount = 0;
    private CarController carController;
    private SplineCalculator splineCalculator;
    private Rigidbody rb;
    private RayPerceptionSensorComponent3D rayPerceptionSensor;
    private AIController aiController;
    [SerializeField] private bool isPlayer = false;

    private void Awake() {
        carController = GetComponent<CarController>();
        rb = GetComponent<Rigidbody>();
        splineCalculator = FindObjectOfType<SplineCalculator>();
        aiController = GetComponent<AIController>();
        if (rb != null)
        {
            Debug.Log("rb is not null");
        }
    }
    private void Start()
    {
        rayPerceptionSensor = GetComponent<RayPerceptionSensorComponent3D>();
        checksOver = 0;
        start = true;
        //trackCheckpoints = FindObjectOfType<TrackCheckpoints>();
        trackCheckpoints.OnPlayerCorrectCheckpoint += TrackCheckpoints_OnCarCorrectCheckpoint;
        trackCheckpoints.OnPlayerWrongCheckpoint += TrackCheckpoints_OnCarWrongCheckpoint;
        //carController = GetComponent<CarController>();
        //rb = GetComponent<Rigidbody>();
    }

    private void TrackCheckpoints_OnCarCorrectCheckpoint(object sender, TrackCheckpoints.CarCheckpointEventArgs e)
    {
        if (e.carTransform == transform){
            AddReward(10f + ((float)checksOver / 5f));
            timer += 1f;
            checksOver++;
        }
    }

    private void TrackCheckpoints_OnCarWrongCheckpoint(object sender, TrackCheckpoints.CarCheckpointEventArgs e)
    {
        if (e.carTransform == transform){
            AddReward(-2f);
        }
    }

    void Update()
    {
        if (start == true)
        {
            if (splineCalculator.GetDistanceToSpline(transform.position) < 2) AddReward(0.05f);
            //Debug.Log("Distance to spline: " + splineCalculator.GetDistanceToSpline(transform.position));
            if ((carController.CurrentSpeed() * 3.6 >= 20f) && (carController.IsMovingForward())) AddReward(0.05f);
            speedText.text = (carController.CurrentSpeed() * 3.6).ToString("0.0");
            timer -= Time.deltaTime;
            value.text = timer.ToString("0.00");
            checksGone.text = checksOver.ToString();
            allChecks.text = TrackCheckpoints.GetChecks().ToString();
            rewardNum.text = GetCumulativeReward().ToString();
            if (timer <= 0)
            {
                AddReward(-10f);
                EndEpisode();
            } else if (checksOver == TrackCheckpoints.GetChecks())
            {
                AddReward(5000f);
                EndEpisode();
            }
            if (carController.CurrentSpeed() < 0.5f)
                AddReward(-0.01f);  // мелкое наказание за бездействие
            float distance = splineCalculator.GetDistanceToSpline(transform.position);
            //AddReward(Mathf.Clamp(0.05f - distance * 0.01f, -0.01f, 0.05f));
        }
    }
    public override void OnEpisodeBegin()
    {
        //carController = GetComponent<CarController>();
        //rb = GetComponent<Rigidbody>();
        transform.position = spawnPosition.position + new Vector3(Random.Range(-1f,1f),0,Random.Range(-1f,1f));
        transform.forward = spawnPosition.forward;
        trackCheckpoints.ResetCheckpoint(transform);
        checksOver = 0;
        timer = 30f;

        stepCount = 0;
        rb.velocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
    }
    public override void CollectObservations(VectorSensor sensor)
    {
        // var rayInput = rayPerceptionSensor.GetRayPerceptionInput();
        // var rayOutput = RayPerceptionSensor.Perceive(rayInput);
        // for (int rayIndex = 0; rayIndex < rayOutput.RayOutputs.Length; rayIndex++)
        // {
        //     var ray = rayOutput.RayOutputs[rayIndex];
        //     sensor.AddObservation(ray.HasHit ? 1f : 0f);
        //     Debug.Log(rayIndex + " ray.HitFraction " + (ray.HasHit ? 1f : 0f));
        //     //Debug.Log(ray + "ray.HitFraction" + ray.HitFraction);
        //     sensor.AddObservation(ray.HitFraction);
        // }


        sensor.AddObservation(splineCalculator.GetDistanceToSpline(transform.position));
        //Debug.Log("Distance to spline: " + splineCalculator.GetDistanceToSpline(transform.position));
        float distance = trackCheckpoints.GetDistanceToNextCheckpoint(transform);
        //Debug.Log("Distance to next checkpoint: " + distance);

        sensor.AddObservation(distance);
        Vector3 checkpointForward = trackCheckpoints.GetNextCheckpoint(transform).transform.forward;
        float directionDot = Vector3.Dot(transform.forward, checkpointForward);
        sensor.AddObservation(directionDot);
        Debug.Log(directionDot);
        Debug.Log(checkpointForward);
        //Debug.Log("Speed: " + rb.velocity.magnitude);
        // Debug.Log(sensor);
        sensor.AddObservation(rb.velocity.magnitude);
    }
    public override void OnActionReceived(ActionBuffers actions)
    {
        float forwardAmount = 0f;
        float turnAmount = 0f;
        //float forwardAmount = -1f + 0.2f*(float)actions.DiscreteActions[0];
        // switch(actions.DiscreteActions[0])
        // {
        //     case 0: forwardAmount = -1f; break;
        //     case 1: forwardAmount = -0.9f; break;
        //     case 2: forwardAmount = -0.8f; break;
        //     case 3: forwardAmount = -0.7f; break;
        //     case 4: forwardAmount = -0.6f; break;
        //     case 5: forwardAmount = -0.5f; break;
        //     case 6: forwardAmount = -0.4f; break;
        //     case 7: forwardAmount = -0.3f; break;
        //     case 8: forwardAmount = -0.2f; break;
        //     case 9: forwardAmount = -0.1f; break;
        //     case 10: forwardAmount = 0f; break;
        //     case 11: forwardAmount = 0.1f; break;
        //     case 12: forwardAmount = 0.2f; break;
        //     case 13: forwardAmount = 0.3f; break;
        //     case 14: forwardAmount = 0.4f; break;
        //     case 15: forwardAmount = 0.5f; break;
        //     case 16: forwardAmount = 0.6f; break;
        //     case 17: forwardAmount = 0.7f; break;
        //     case 18: forwardAmount = 0.8f; break;
        //     case 19: forwardAmount = 0.9f; break;
        //     case 20: forwardAmount = 1f; break;
        // }
        //float turnAmount = -1f + 0.2f*(float)actions.DiscreteActions[1];
        // switch(actions.DiscreteActions[1])
        // {
        //     case 0: turnAmount = -1f; break;
        //     case 1: turnAmount = -0.9f; break;
        //     case 2: turnAmount = -0.8f; break;
        //     case 3: turnAmount = -0.7f; break;
        //     case 4: turnAmount = -0.6f; break;
        //     case 5: turnAmount = -0.5f; break;
        //     case 6: turnAmount = -0.4f; break;
        //     case 7: turnAmount = -0.3f; break;
        //     case 8: turnAmount = -0.2f; break;
        //     case 9: turnAmount = -0.1f; break;
        //     case 10: turnAmount = 0f; break;
        //     case 11: turnAmount = 0.1f; break;
        //     case 12: turnAmount = 0.2f; break;
        //     case 13: turnAmount = 0.3f; break;
        //     case 14: turnAmount = 0.4f; break;
        //     case 15: turnAmount = 0.5f; break;
        //     case 16: turnAmount = 0.6f; break;
        //     case 17: turnAmount = 0.7f; break;
        //     case 18: turnAmount = 0.8f; break;
        //     case 19: turnAmount = 0.9f; break;
        //     case 20: turnAmount = 1f; break;
        // }
        // switch(actions.DiscreteActions[0])
        // {
        //     case 0: brakeAmount = false; break;
        //     case 1: brakeAmount = true; break;
        // }


        var rayInput = rayPerceptionSensor.GetRayPerceptionInput();
        var rayOutput = RayPerceptionSensor.Perceive(rayInput);
        //if (rayOutput.RayOutputs[2].HitTaggedObject && rayOutput.RayOutputs[2].HitTagIndex == 1  && (turnAmount <= -0.2) && (turnAmount >= 0.2)) AddReward(-1);
        if (forwardAmount > 0.8)
        {
            AddReward(forwardSpeedReward);
        }
        forwardAmount = actions.ContinuousActions[0];
        turnAmount = actions.ContinuousActions[1];
        //if (Mathf.Abs(turnAmount) < 0.2f)
        //    AddReward(0.01f);  // стимулируем прямое движение
        //brakeAmount = actions.DiscreteActions[0];
        //Debug.Log(forwardAmount);
        //Debug.Log(turnAmount);
        carController.SetInput(forwardAmount,turnAmount);

        AddReward(perStepPenalty);

        stepCount++;
        if (stepCount >= maxSteps)
        {
            AddReward(-10f);
            EndEpisode();
        }
    }
    public override void Heuristic(in ActionBuffers actionsOut)
    {
        float forwardAction = 0f;
        //if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W)) forwardAction = 10;
        //if (Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S)) forwardAction = 0;
        //forwardAction = Input.GetAxis("Vertical");

        float turnAction = 0f;
        //if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D)) turnAction = 10;
        //if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A)) turnAction = 0;
        //turnAction = Input.GetAxis("Horizontal");

//        int brakeAction = 0;
//        if (Input.GetKey(KeyCode.Space)) brakeAction = 1;
        if (isPlayer)
        {
            forwardAction = Input.GetAxis("Vertical");
            turnAction = Input.GetAxis("Horizontal");
        } else
        {
            forwardAction = aiController.InputVerticalAI();
            turnAction = aiController.InputHorizontalAI();
        }
        // forwardAction = aiController.InputVerticalAI();
        // turnAction = aiController.InputHorizontalAI();

        ActionSegment<float> continuousActions = actionsOut.ContinuousActions;
        //ActionSegment<int> discreteActions = actionsOut.DiscreteActions;
        continuousActions[0] = forwardAction;
        continuousActions[1] = turnAction;
//        discreteActions[0] = brakeAction;
    }

    private void OnCollisionEnter(Collision other) {
        if (other.gameObject.TryGetComponent<Wall>(out Wall wall))
        {
            AddReward(-10f);
            //EndEpisode();
        }
        if (other.gameObject.TryGetComponent<Player>(out Player player))
        {
            //AddReward(-10f);
            //EndEpisode();
        }
    }
    private void OnCollisionStay(Collision other) {
        if (other.gameObject.TryGetComponent<Wall>(out Wall wall))
        {
            AddReward(-1f);
        }
    }
}